public class App {
    public static void main(String[] args){
        MetodoGenerico mg = new MetodoGenerico();
        mg.souGenerico("A", 1 , 1.0);
       
    }
}
