public class App {
    public static void main(String[] args)  {
        Prova prova1 = new Prova();
        prova1.aplicar();
    }
}
