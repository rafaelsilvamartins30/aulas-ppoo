public interface Segurado {
    double calcularPremio();
}