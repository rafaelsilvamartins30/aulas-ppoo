public class App {
    public static void main(String[] args){
        Sig sig = new Sig();
        sig.executar();
       
        
    }
}